package com.example.qimo.ui.weather.weather

data class CityInfo(
    val city: String,
    val citykey: String,
    val parent: String,
    val updateTime: String
)